var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_a6d89067._.js")
R.c("server/chunks/[root-of-the-server]__b7ab475e._.js")
R.c("server/chunks/20be1_next_dist_esm_build_templates_app-route_bca76d34.js")
R.c("server/chunks/c0756_Standing shield__next-internal_server_app_favicon_ico_route_actions_b3742c2c.js")
R.m(60148)
module.exports=R.m(60148).exports
