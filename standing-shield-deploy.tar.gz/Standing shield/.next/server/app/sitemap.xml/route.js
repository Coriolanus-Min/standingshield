var R=require("../../chunks/[turbopack]_runtime.js")("server/app/sitemap.xml/route.js")
R.c("server/chunks/[root-of-the-server]__f7508edb._.js")
R.c("server/chunks/[root-of-the-server]__b7ab475e._.js")
R.c("server/chunks/c0756_Standing shield__next-internal_server_app_sitemap_xml_route_actions_d1653367.js")
R.m(78690)
module.exports=R.m(78690).exports
