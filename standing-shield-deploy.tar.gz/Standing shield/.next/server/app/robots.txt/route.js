var R=require("../../chunks/[turbopack]_runtime.js")("server/app/robots.txt/route.js")
R.c("server/chunks/[root-of-the-server]__f7c7f122._.js")
R.c("server/chunks/[root-of-the-server]__b7ab475e._.js")
R.c("server/chunks/c0756_Standing shield__next-internal_server_app_robots_txt_route_actions_96c9c3b4.js")
R.m(34994)
module.exports=R.m(34994).exports
