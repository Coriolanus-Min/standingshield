1:"$Sreact.fragment"
2:I[15686,["/_next/static/chunks/ed19a28d5baa431c.js","/_next/static/chunks/d795b7c1a0824962.js","/_next/static/chunks/e291621f255fbaac.js"],"default"]
3:I[40143,["/_next/static/chunks/b75fcfba598f316b.js","/_next/static/chunks/064619fd0e2e6e69.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"z2knSlMYTi3ci6Tlp2ynr","rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/_next/static/chunks/e291621f255fbaac.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
