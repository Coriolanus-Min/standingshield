1:"$Sreact.fragment"
2:I[15818,["/_next/static/chunks/b75fcfba598f316b.js","/_next/static/chunks/064619fd0e2e6e69.js"],"default"]
3:I[25725,["/_next/static/chunks/b75fcfba598f316b.js","/_next/static/chunks/064619fd0e2e6e69.js"],"default"]
0:{"buildId":"z2knSlMYTi3ci6Tlp2ynr","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
