module.exports=[35205,(e,o,d)=>{}];

//# sourceMappingURL=c0756_Standing%20shield__next-internal_server_app_robots_txt_route_actions_96c9c3b4.js.map