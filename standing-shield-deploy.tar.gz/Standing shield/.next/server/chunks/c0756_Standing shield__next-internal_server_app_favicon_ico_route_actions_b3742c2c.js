module.exports=[83744,(e,o,d)=>{}];

//# sourceMappingURL=c0756_Standing%20shield__next-internal_server_app_favicon_ico_route_actions_b3742c2c.js.map