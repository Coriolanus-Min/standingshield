module.exports=[11339,(a,b,c)=>{}];

//# sourceMappingURL=c0756_Standing%20shield__next-internal_server_app_contact_page_actions_32870180.js.map