module.exports=[59687,(a,b,c)=>{}];

//# sourceMappingURL=c0756_Standing%20shield__next-internal_server_app__global-error_page_actions_cfbdac5f.js.map