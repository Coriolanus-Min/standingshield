module.exports=[58301,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},13877,a=>{"use strict";let b={src:a.i(58301).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=my%20project_Kiro-CLI_Standing%20shield_src_app_a1743c6e._.js.map