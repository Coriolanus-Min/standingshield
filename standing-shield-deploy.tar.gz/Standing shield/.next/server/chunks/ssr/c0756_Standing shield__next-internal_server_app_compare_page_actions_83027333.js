module.exports=[37348,(a,b,c)=>{}];

//# sourceMappingURL=c0756_Standing%20shield__next-internal_server_app_compare_page_actions_83027333.js.map