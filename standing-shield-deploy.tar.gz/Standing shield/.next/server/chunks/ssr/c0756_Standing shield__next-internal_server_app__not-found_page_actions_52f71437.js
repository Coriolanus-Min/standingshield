module.exports=[36469,(a,b,c)=>{}];

//# sourceMappingURL=c0756_Standing%20shield__next-internal_server_app__not-found_page_actions_52f71437.js.map