module.exports=[4585,(a,b,c)=>{}];

//# sourceMappingURL=c0756_Standing%20shield__next-internal_server_app_products_%5Bslug%5D_page_actions_b7baa5ad.js.map