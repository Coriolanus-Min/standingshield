globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/cbba13cc329dfdb0.js",
    "static/chunks/fc3a0607dc2e8269.js",
    "static/chunks/beb96d1544876cb5.js",
    "static/chunks/c2e3ac8cfbafb7ab.js",
    "static/chunks/turbopack-193dc5da574af201.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];